# 8
def decorator_timer(calc_function):
    from time import time

    def wrapper(*args, **kwargs):
        t1 = time()
        result = calc_function(*args, **kwargs)
        end = time()-t1
        return result, end
    return wrapper


@decorator_timer
def my_pow(a, b):
    res = a ** b
    return res

result, exec_time = my_pow(199999 , 200000)
print(exec_time) 

# 9

class Celsius:
    def __init__(self, temperature=0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    def get_temperature(self):
        print("Getting value...")
        return self._temperature

    def set_temperature(self, value):
        print("Setting value...")
        if value < -273.15:
            raise ValueError("Temperature below -273.15 is not possible")
        self._temperature = value

    # creating a property object
    temperature = property(get_temperature, set_temperature)


human = Celsius(37)

print(human.temperature)

print(human.to_fahrenheit())


