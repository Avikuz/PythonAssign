# 1
def reverseWordSentence(s):
    return ' '.join(i[::-1] for i in s.split(" "))
# 2
def reverseWordSentence(s):

  reversedSentence =' '.join(i[::-1] for i in s.split(" "))

  newSentence = ''

  for i in range(len(s)):

    if s[i].isupper():

      newSentence += reversedSentence[i].upper()

    else:

      newSentence += reversedSentence[i].lower()

  return newSentence
# 3
def listmanipulation(number_list):

  for i in list(number_list):

    if i > 50:

      number_list.remove(i)

  return number_list
# 4
from collections import Counter

def listOccurenceCounter(sample_list):

  d = Counter(sample_list)

  new_list = list([item for item in d if d[item]>1])

  print(new_list)
#5
def dictionaryIteration(ascii_dict):

  reversed_dict = {value : key for key, value in dict.items(ascii_dict)}

  print(reversed_dict)
#6
rows = int(input("Enter the number of rows: "))   

for i in range(rows,0,-1): 

    for j in range(i): 

        print(rows - (i -1), end=' ')  

    print(" ")  
